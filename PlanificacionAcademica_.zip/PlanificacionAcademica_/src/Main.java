import excepciones.EstudianteNoEncontradoException;
import estructuras.HistorialOperaciones;
import excepciones.ArchivoInvalidoException;
import excepciones.HorarioConflictivoException;
import excepciones.PilaDeshacerVaciaException;
import excepciones.PreRequisitoNoAprobadoException;
import modelo.Aula;
import modelo.Campus;
import modelo.CatalogoFacultades;
import modelo.Facultad;
import modelo.Estudiante;
import modelo.GeneradorReportes;
import modelo.GestorAulas;
import modelo.GestorEstudiantes;
import modelo.GestorMaterias;
import modelo.Materia;
import modelo.NavegadorReportes;
import modelo.OperacionCancelarInscripcion;
import modelo.OperacionEliminarEstudiante;
import modelo.OperacionHorario;
import modelo.OperacionInscribir;
import modelo.OperacionRegistrarNota;
import modelo.ProcesadorLotes;
import modelo.ResultadoLote;
import modelo.Ruta;
import java.util.List;
import java.util.Scanner;

/**
 * Clase principal. Módulos listos: estudiantes (1-4), materias (5-10), horarios (11-13) y rutas (14-15) reportes (16-18) y deshacer/rehacer (19-20) lotes (21) y salir (22).
 * Las demás opciones del menú se irán agregando.
 */
public class Main {

    private static final Scanner sc = new Scanner(System.in);
    private static final GestorEstudiantes gestorEstudiantes = new GestorEstudiantes();
    private static final GestorMaterias gestorMaterias = new GestorMaterias();
    private static final GestorAulas gestorAulas = new GestorAulas();
    private static final Campus campus = new Campus();
    private static final CatalogoFacultades facultades = new CatalogoFacultades();
    private static final NavegadorReportes navegador = new NavegadorReportes();
    private static final HistorialOperaciones historial = new HistorialOperaciones();
    private static final ProcesadorLotes procesador =
            new ProcesadorLotes(gestorEstudiantes, gestorMaterias, historial);

    // Aulas de ejemplo precargadas para poder probar los horarios.
    static {
        gestorAulas.crear(new Aula("101", 30));
        gestorAulas.crear(new Aula("102", 25));
        gestorAulas.crear(new Aula("201", 40));

        // Las 5 facultades (arreglo fijo).
        facultades.agregar(new Facultad("ING", "Ingenieria"));
        facultades.agregar(new Facultad("CBA", "Ciencias Basicas"));
        facultades.agregar(new Facultad("ECO", "Ciencias Economicas y Administrativas"));
        facultades.agregar(new Facultad("SAL", "Ciencias de la Salud"));
        facultades.agregar(new Facultad("HUM", "Humanidades y Educacion"));

        // Edificios y conexiones de ejemplo (metros).
        int ing = campus.agregarEdificio("Ingenieria");
        int bib = campus.agregarEdificio("Biblioteca");
        int caf = campus.agregarEdificio("Cafeteria");
        int rec = campus.agregarEdificio("Rectoria");
        int lab = campus.agregarEdificio("Laboratorios");
        campus.conectar(ing, bib, 100);
        campus.conectar(ing, caf, 150);
        campus.conectar(bib, caf, 120);
        campus.conectar(bib, rec, 400);
        campus.conectar(caf, rec, 180);
        campus.conectar(caf, lab, 90);
        campus.conectar(lab, rec, 250);
    }

    public static void main(String[] args) {
        int opcion;
        do {
            mostrarMenu();
            opcion = leerEntero("Seleccione una opcion: ");
            switch (opcion) {
                case 1: registrarEstudiante(); break;
                case 2: buscarEstudiante(); break;
                case 3: listarEstudiantes(); break;
                case 4: eliminarEstudiante(); break;
                case 5: crearMateria(); break;
                case 6: agregarPrerrequisito(); break;
                case 7: mostrarPrerrequisitos(); break;
                case 8: inscribirEstudiante(); break;
                case 9: cancelarInscripcion(); break;
                case 10: mostrarColaEspera(); break;
                case 11: reservarHorario(); break;
                case 12: liberarHorario(); break;
                case 13: consultarDisponibilidad(); break;
                case 14: agregarConexion(); break;
                case 15: calcularRuta(); break;
                case 16: registrarNota(); break;
                case 17: verReporte(); break;
                case 18: navegarReportes(); break;
                case 19: deshacerOperacion(); break;
                case 20: rehacerOperacion(); break;
                case 21: procesarArchivoCsv(); break;
                case 22: System.out.println("Hasta luego."); break;
                default: System.out.println("Opcion no valida.");
            }
        } while (opcion != 22);
    }

    private static void mostrarMenu() {
        System.out.println("\n============================================================");
        System.out.println("PLANIFICACION ACADEMICA - SISTEMA UNIVERSITARIO");
        System.out.println("============================================================");
        System.out.println("=== GESTION DE ESTUDIANTES ===");
        System.out.println("1. Registrar estudiante");
        System.out.println("2. Buscar estudiante por ID");
        System.out.println("3. Listar todos los estudiantes");
        System.out.println("4. Eliminar estudiante");
        System.out.println("=== GESTION DE MATERIAS ===");
        System.out.println("5. Crear materia");
        System.out.println("6. Agregar pre-requisito");
        System.out.println("7. Mostrar pre-requisitos");
        System.out.println("8. Inscribir estudiante");
        System.out.println("9. Cancelar inscripcion");
        System.out.println("10. Mostrar cola de espera");
        System.out.println("=== GESTION DE HORARIOS ===");
        System.out.println("11. Reservar horario en aula");
        System.out.println("12. Liberar horario");
        System.out.println("13. Consultar disponibilidad");
        System.out.println("=== RUTAS ENTRE EDIFICIOS ===");
        System.out.println("14. Agregar conexion entre edificios");
        System.out.println("15. Calcular ruta mas corta");
        System.out.println("=== REPORTES ACADEMICOS ===");
        System.out.println("16. Registrar nota");
        System.out.println("17. Ver reporte academico");
        System.out.println("18. Navegador de reportes (atras/adelante)");
        System.out.println("=== SISTEMA DESHACER/REHACER ===");
        System.out.println("19. Deshacer ultima operacion");
        System.out.println("20. Rehacer ultima operacion");
        System.out.println("=== PROCESAMIENTO POR LOTES ===");
        System.out.println("21. Procesar archivo CSV");
        System.out.println("=== SALIR ===");
        System.out.println("22. Salir");
    }

    // ---------------------------------------------------------------- ESTUDIANTES

    private static void registrarEstudiante() {
        System.out.println("--- REGISTRO DE ESTUDIANTE ---");
        String id = leerTexto("ID: ");
        String nombre = leerTexto("Nombre: ");
        String email = leerTexto("Email: ");
        int semestre = leerEntero("Semestre actual: ");
        System.out.println("Facultades:");
        for (int i = 1; i <= facultades.getCantidad(); i++) {
            System.out.println(i + ". " + facultades.obtener(i).getNombre());
        }
        int opcionFacultad = leerEntero("Facultad (1-" + facultades.getCantidad() + ", 0 = ninguna): ");

        if (id.isEmpty() || nombre.isEmpty()) {
            System.out.println("Error: el ID y el nombre no pueden estar vacios.");
            return;
        }
        try {
            Estudiante nuevo = new Estudiante(nombre, id, email, semestre);
            if (opcionFacultad != 0) {
                nuevo.setFacultad(facultades.obtener(opcionFacultad));
            }
            gestorEstudiantes.registrar(nuevo);
            System.out.println("Estudiante registrado exitosamente.");
        } catch (IllegalArgumentException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    private static void buscarEstudiante() {
        System.out.println("--- BUSCAR ESTUDIANTE ---");
        String id = leerTexto("ID: ");
        try {
            Estudiante e = gestorEstudiantes.buscar(id);
            System.out.println("Resultado encontrado:");
            e.mostrarInformacion();
        } catch (EstudianteNoEncontradoException ex) {
            System.out.println("Error: EstudianteNoEncontradoException - " + ex.getMessage());
        }
    }

    private static void listarEstudiantes() {
        List<Estudiante> lista = gestorEstudiantes.listar();
        if (lista.isEmpty()) {
            System.out.println("No hay estudiantes registrados.");
            return;
        }
        System.out.println("--- ESTUDIANTES REGISTRADOS (" + lista.size() + ") ---");
        for (Estudiante e : lista) {
            e.mostrarInformacion();
            System.out.println("------------------------------");
        }
    }

    private static void eliminarEstudiante() {
        System.out.println("--- ELIMINAR ESTUDIANTE ---");
        String id = leerTexto("ID: ");
        try {
            Estudiante eliminado = gestorEstudiantes.eliminar(id);
            System.out.println("Estudiante eliminado: " + eliminado.getNombre());
            historial.registrar(new OperacionEliminarEstudiante(gestorEstudiantes, eliminado));
        } catch (EstudianteNoEncontradoException ex) {
            System.out.println("Error: EstudianteNoEncontradoException - " + ex.getMessage());
        }
    }

    // ------------------------------------------------------------------- MATERIAS

    private static void crearMateria() {
        System.out.println("--- CREAR MATERIA ---");
        String codigo = leerTexto("Codigo: ");
        String nombre = leerTexto("Nombre: ");
        int cupos = leerEntero("Cupos maximos: ");
        int creditos = leerEntero("Creditos: ");

        if (codigo.isEmpty() || nombre.isEmpty() || cupos <= 0 || creditos <= 0) {
            System.out.println("Error: codigo y nombre obligatorios; cupos y creditos deben ser mayores que 0.");
            return;
        }
        try {
            gestorMaterias.crear(new Materia(codigo, nombre, cupos, creditos));
            System.out.println("Materia creada exitosamente.");
        } catch (IllegalArgumentException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    private static void agregarPrerrequisito() {
        System.out.println("--- AGREGAR PRE-REQUISITO ---");
        String codigo = leerTexto("Codigo de la materia: ");
        String pre = leerTexto("Codigo del pre-requisito: ");
        try {
            gestorMaterias.agregarPrerrequisito(codigo, pre);
            System.out.println("Pre-requisito agregado.");
        } catch (IllegalArgumentException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    private static void mostrarPrerrequisitos() {
        System.out.println("--- PRE-REQUISITOS ---");
        String codigo = leerTexto("Codigo de la materia: ");
        try {
            Materia m = gestorMaterias.buscar(codigo);
            if (m.getPrerrequisitos().isEmpty()) {
                System.out.println(m.getCodigo() + " no tiene pre-requisitos.");
                return;
            }
            System.out.println("Pre-requisitos de " + m.getCodigo() + " - " + m.getNombre() + ":");
            for (String pre : m.getPrerrequisitos()) {
                System.out.println(" - " + pre);
            }
        } catch (IllegalArgumentException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    private static void inscribirEstudiante() {
        System.out.println("--- INSCRIBIR ESTUDIANTE ---");
        String idEst = leerTexto("ID del estudiante: ");
        String codigo = leerTexto("Codigo de la materia: ");
        try {
            Estudiante e = gestorEstudiantes.buscar(idEst);
            boolean inscrito = gestorMaterias.inscribir(e, codigo);
            Materia m = gestorMaterias.buscar(codigo);
            historial.registrar(new OperacionInscribir(m, e, inscrito));
            if (inscrito) {
                System.out.println(e.getNombre() + " -> Cupo disponible (cupos restantes: "
                        + m.cuposDisponibles() + ")");
            } else {
                System.out.println(e.getNombre() + " -> Materia llena. Agregado a COLA DE ESPERA");
            }
        } catch (EstudianteNoEncontradoException ex) {
            System.out.println("Error: EstudianteNoEncontradoException - " + ex.getMessage());
        } catch (PreRequisitoNoAprobadoException ex) {
            System.out.println("Error: PreRequisitoNoAprobadoException - " + ex.getMessage());
        } catch (IllegalArgumentException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    private static void cancelarInscripcion() {
        System.out.println("--- CANCELAR INSCRIPCION ---");
        String idEst = leerTexto("ID del estudiante: ");
        String codigo = leerTexto("Codigo de la materia: ");
        try {
            Estudiante e = gestorEstudiantes.buscar(idEst);
            Estudiante promovido = gestorMaterias.cancelarInscripcion(e, codigo);
            historial.registrar(new OperacionCancelarInscripcion(gestorMaterias.buscar(codigo), e, promovido));
            System.out.println("Cancelacion exitosa. Cupo liberado.");
            if (promovido != null) {
                System.out.println("Asignando cupo a " + promovido.getNombre() + " (primer estudiante en cola)");
            }
        } catch (EstudianteNoEncontradoException ex) {
            System.out.println("Error: EstudianteNoEncontradoException - " + ex.getMessage());
        } catch (IllegalArgumentException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    private static void mostrarColaEspera() {
        System.out.println("--- MOSTRAR COLA DE ESPERA ---");
        String codigo = leerTexto("Codigo de la materia: ");
        try {
            List<Estudiante> cola = gestorMaterias.verCola(codigo);
            if (cola.isEmpty()) {
                System.out.println("La cola de espera esta vacia.");
                return;
            }
            for (int i = 0; i < cola.size(); i++) {
                System.out.println("Posicion " + (i + 1) + ": " + cola.get(i).getNombre());
            }
            System.out.println("Total en espera: " + cola.size());
        } catch (IllegalArgumentException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    // ------------------------------------------------------------------- HORARIOS

    private static void reservarHorario() {
        System.out.println("--- RESERVAR HORARIO EN AULA ---");
        String nombreAula = leerTexto("Aula: ");
        int dia = leerEntero("Dia (0=Domingo, 1=Lunes ... 6=Sabado): ");
        int hora = leerEntero("Hora (0-23): ");
        int duracion = leerEntero("Duracion (horas): ");
        try {
            Aula aula = gestorAulas.buscar(nombreAula);
            aula.validarRango(dia, hora, duracion);
            System.out.println("Verificando disponibilidad...");
            for (int h = hora; h < hora + duracion; h++) {
                String estado = aula.consultarDisponibilidad(dia, h) ? "LIBRE" : "OCUPADO";
                System.out.println(Aula.nombreDia(dia) + " " + h + ":00 -> " + estado);
            }
            aula.reservar(dia, hora, duracion);
            historial.registrar(new OperacionHorario(aula, dia, hora, duracion, true));
            System.out.println("Reserva exitosa.");
        } catch (HorarioConflictivoException ex) {
            System.out.println("Error: HorarioConflictivoException - " + ex.getMessage());
        } catch (IllegalArgumentException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    private static void liberarHorario() {
        System.out.println("--- LIBERAR HORARIO ---");
        String nombreAula = leerTexto("Aula: ");
        int dia = leerEntero("Dia (0=Domingo, 1=Lunes ... 6=Sabado): ");
        int hora = leerEntero("Hora (0-23): ");
        int duracion = leerEntero("Duracion (horas): ");
        try {
            Aula aula = gestorAulas.buscar(nombreAula);
            aula.liberar(dia, hora, duracion);
            historial.registrar(new OperacionHorario(aula, dia, hora, duracion, false));
            System.out.println("Horario liberado.");
        } catch (IllegalArgumentException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    private static void consultarDisponibilidad() {
        System.out.println("--- CONSULTAR DISPONIBILIDAD ---");
        String nombreAula = leerTexto("Aula: ");
        int dia = leerEntero("Dia (0=Domingo, 1=Lunes ... 6=Sabado): ");
        int hora = leerEntero("Hora (0-23): ");
        try {
            boolean libre = gestorAulas.buscar(nombreAula).consultarDisponibilidad(dia, hora);
            System.out.println(Aula.nombreDia(dia) + " " + hora + ":00 -> " + (libre ? "LIBRE" : "OCUPADO"));
        } catch (IllegalArgumentException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    // ---------------------------------------------------------------------- RUTAS

    private static void mostrarEdificios() {
        System.out.println("Edificios registrados:");
        for (int i = 0; i < campus.getCantidad(); i++) {
            System.out.println(i + ": " + campus.getNombre(i));
        }
    }

    private static void agregarConexion() {
        System.out.println("--- AGREGAR CONEXION ENTRE EDIFICIOS ---");
        mostrarEdificios();
        String origen = leerTexto("Edificio 1: ");
        String destino = leerTexto("Edificio 2: ");
        int metros = leerEntero("Distancia (metros): ");
        try {
            campus.conectar(campus.buscarIndice(origen), campus.buscarIndice(destino), metros);
            System.out.println("Conexion registrada.");
        } catch (IllegalArgumentException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    private static void calcularRuta() {
        System.out.println("--- CALCULAR RUTA MAS CORTA ---");
        mostrarEdificios();
        String origen = leerTexto("Origen: ");
        String destino = leerTexto("Destino: ");
        try {
            Ruta ruta = campus.calcularRutaMasCorta(campus.buscarIndice(origen), campus.buscarIndice(destino));
            int[] camino = ruta.getCamino();
            System.out.println("--- RESULTADO ---");
            System.out.println("Ruta mas corta:");
            StringBuilder sb = new StringBuilder(campus.getNombre(camino[0]));
            for (int i = 1; i < camino.length; i++) {
                int tramo = campus.distanciaDirecta(camino[i - 1], camino[i]);
                sb.append(" -> ").append(campus.getNombre(camino[i])).append(" (").append(tramo).append("m)");
            }
            System.out.println(sb);
            System.out.println("Distancia TOTAL: " + ruta.getDistanciaTotal() + " metros");
        } catch (IllegalArgumentException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    // -------------------------------------------------------------------- REPORTES

    private static void registrarNota() {
        System.out.println("--- REGISTRAR NOTA ---");
        String idEst = leerTexto("ID del estudiante: ");
        int semestre = leerEntero("Semestre (1-10): ");
        String codigo = leerTexto("Codigo de la materia: ");
        double nota = leerDecimal("Nota (0.0 a 5.0): ");
        try {
            Estudiante e = gestorEstudiantes.buscar(idEst);
            gestorMaterias.buscar(codigo);   // valida que la materia exista
            Double anterior = e.getNotaDeMateria(semestre, codigo);
            e.registrarNota(semestre, codigo, nota);
            historial.registrar(new OperacionRegistrarNota(e, semestre, codigo, anterior, nota));
            System.out.println("Nota registrada: " + codigo + " = " + nota
                    + (nota >= Estudiante.NOTA_APROBATORIA ? " (aprobada)" : " (reprobada)"));
        } catch (EstudianteNoEncontradoException ex) {
            System.out.println("Error: EstudianteNoEncontradoException - " + ex.getMessage());
        } catch (IllegalArgumentException | IllegalStateException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    private static void verReporte() {
        String idEst = leerTexto("ID del estudiante: ");
        try {
            String reporte = GeneradorReportes.generar(gestorEstudiantes.buscar(idEst));
            System.out.println(reporte);
            navegador.visitar(reporte);      // se apila en el historial de navegación
        } catch (EstudianteNoEncontradoException ex) {
            System.out.println("Error: EstudianteNoEncontradoException - " + ex.getMessage());
        }
    }

    private static void navegarReportes() {
        if (navegador.getActual() == null) {
            System.out.println("No hay reportes vistos todavia. Use primero la opcion 17.");
            return;
        }
        int opcion;
        do {
            System.out.println("\n=== REPORTE ACTUAL ===");
            System.out.println(navegador.getActual());
            System.out.println("1. Atras" + (navegador.hayAtras() ? "" : " (no disponible)"));
            System.out.println("2. Adelante" + (navegador.hayAdelante() ? "" : " (no disponible)"));
            System.out.println("0. Volver al menu");
            opcion = leerEntero("Seleccione: ");
            try {
                if (opcion == 1) navegador.retroceder();
                else if (opcion == 2) navegador.avanzar();
            } catch (IllegalStateException ex) {
                System.out.println("Error: " + ex.getMessage());
            }
        } while (opcion != 0);
    }

    // ----------------------------------------------------------------------- LOTES

    private static void procesarArchivoCsv() {
        System.out.println("--- PROCESAMIENTO MASIVO (BATCH) ---");
        String ruta = leerTexto("Archivo (ejemplo: inscripciones.csv): ");
        try {
            ResultadoLote r = procesador.procesar(ruta);
            System.out.println("Archivo: " + ruta);
            for (String ignorada : r.getLineasIgnoradas()) {
                System.out.println(ignorada);
            }
            System.out.println("Se encolaron " + r.getTotal() + " solicitudes.");
            System.out.println("Procesando cola...");
            for (String linea : r.getDetalle()) {
                System.out.println(linea);
            }
            System.out.println("=== RESUMEN ===");
            System.out.println("Exitosas: " + r.getExitosas());
            System.out.println("Fallidas: " + r.getFallidas());
            if (!r.getLineasIgnoradas().isEmpty()) {
                System.out.println("Lineas ignoradas por formato invalido: " + r.getLineasIgnoradas().size());
            }
        } catch (ArchivoInvalidoException ex) {
            System.out.println("Error: ArchivoInvalidoException - " + ex.getMessage());
        }
    }

    // -------------------------------------------------------- DESHACER / REHACER

    private static void deshacerOperacion() {
        try {
            System.out.println(historial.deshacer());
        } catch (PilaDeshacerVaciaException ex) {
            System.out.println("Error: PilaDeshacerVaciaException - " + ex.getMessage());
        } catch (IllegalStateException | IllegalArgumentException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    private static void rehacerOperacion() {
        try {
            System.out.println(historial.rehacer());
        } catch (PilaDeshacerVaciaException ex) {
            System.out.println("Error: PilaDeshacerVaciaException - " + ex.getMessage());
        } catch (IllegalStateException | IllegalArgumentException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    // ------------------------------------------------------------------- UTILIDAD

    private static String leerTexto(String mensaje) {
        System.out.print(mensaje);
        return sc.nextLine().trim();
    }

    /** Lee un decimal aceptando punto o coma (4.5 o 4,5). */
    private static double leerDecimal(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            try {
                return Double.parseDouble(sc.nextLine().trim().replace(',', '.'));
            } catch (NumberFormatException ex) {
                System.out.println("Debe ingresar un numero (ejemplo: 4.5).");
            }
        }
    }

    /** Lee un entero validando la entrada; repite hasta que sea válido. */
    private static int leerEntero(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            try {
                return Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException ex) {
                System.out.println("Debe ingresar un numero entero.");
            }
        }
    }
}
