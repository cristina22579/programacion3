package estructuras;

/**
 * Una operación que se puede deshacer y rehacer (patrón Comando).
 * Cada implementación guarda el estado anterior que necesita para revertirse.
 * Ambos métodos devuelven un mensaje para mostrar al usuario.
 */
public interface Operacion {

    /** Revierte la operación. */
    String deshacer();

    /** Vuelve a aplicar la operación. */
    String rehacer();
}
