package estructuras;

import excepciones.PilaDeshacerVaciaException;
import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Sistema deshacer/rehacer con dos pilas (ArrayDeque usado como pila, LIFO).
 * - pilaDeshacer: operaciones realizadas, la última en el tope.
 * - pilaRehacer: operaciones deshechas que se pueden volver a aplicar.
 */
public class HistorialOperaciones {

    private final Deque<Operacion> pilaDeshacer = new ArrayDeque<>();
    private final Deque<Operacion> pilaRehacer = new ArrayDeque<>();

    /** Guarda una operación ya ejecutada. Una acción nueva invalida lo que se podía rehacer. */
    public void registrar(Operacion operacion) {
        pilaDeshacer.push(operacion);
        pilaRehacer.clear();
    }

    public String deshacer() throws PilaDeshacerVaciaException {
        if (pilaDeshacer.isEmpty()) {
            throw new PilaDeshacerVaciaException("No hay operaciones para deshacer");
        }
        Operacion op = pilaDeshacer.peek();      // se mira sin sacar, por si falla
        String mensaje = op.deshacer();
        pilaDeshacer.pop();
        pilaRehacer.push(op);
        return mensaje;
    }

    public String rehacer() throws PilaDeshacerVaciaException {
        if (pilaRehacer.isEmpty()) {
            throw new PilaDeshacerVaciaException("No hay operaciones para rehacer");
        }
        Operacion op = pilaRehacer.peek();
        String mensaje = op.rehacer();
        pilaRehacer.pop();
        pilaDeshacer.push(op);
        return mensaje;
    }

    public int cantidadParaDeshacer() { return pilaDeshacer.size(); }
    public int cantidadParaRehacer() { return pilaRehacer.size(); }
}
