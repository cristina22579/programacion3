package modelo;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Administra las aulas en un TreeMap<String, Aula>: el TreeMap mantiene
 * las claves (nombres) siempre ordenadas, así listar() devuelve las aulas ordenadas.
 */
public class GestorAulas {

    private final Map<String, Aula> aulas = new TreeMap<>();

    public void crear(Aula aula) {
        if (aulas.containsKey(aula.getNombre())) {
            throw new IllegalArgumentException("Ya existe el aula: " + aula.getNombre());
        }
        aulas.put(aula.getNombre(), aula);
    }

    public Aula buscar(String nombre) {
        Aula a = aulas.get(nombre);
        if (a == null) {
            throw new IllegalArgumentException("No existe el aula: " + nombre);
        }
        return a;
    }

    /** Aulas ordenadas por nombre. */
    public List<Aula> listar() {
        return new ArrayList<>(aulas.values());
    }
}
