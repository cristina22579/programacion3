package modelo;

import estructuras.Operacion;
import excepciones.CupoLlenoException;

/** Inscripción de un estudiante (quedó inscrito o quedó en la cola de espera). */
public class OperacionInscribir implements Operacion {

    private final Materia materia;
    private final Estudiante estudiante;
    private final boolean quedoInscrito;   // false = quedó en la cola de espera

    public OperacionInscribir(Materia materia, Estudiante estudiante, boolean quedoInscrito) {
        this.materia = materia;
        this.estudiante = estudiante;
        this.quedoInscrito = quedoInscrito;
    }

    @Override
    public String deshacer() {
        if (quedoInscrito) {
            materia.cancelar(estudiante);
            return "Operacion deshecha: " + estudiante.getNombre() + " ya NO esta inscrito en " + materia.getCodigo();
        }
        materia.retirarDeCola(estudiante);
        return "Operacion deshecha: " + estudiante.getNombre() + " ya NO esta en la cola de " + materia.getCodigo();
    }

    @Override
    public String rehacer() {
        try {
            if (quedoInscrito) {
                materia.inscribir(estudiante);
                return "Operacion rehecha: " + estudiante.getNombre() + " inscrito en " + materia.getCodigo();
            }
            materia.encolar(estudiante);
            return "Operacion rehecha: " + estudiante.getNombre() + " en la cola de " + materia.getCodigo();
        } catch (CupoLlenoException ex) {
            throw new IllegalStateException("No se pudo rehacer: " + ex.getMessage());
        }
    }
}
