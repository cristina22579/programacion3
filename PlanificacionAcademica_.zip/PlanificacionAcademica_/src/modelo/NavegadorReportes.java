package modelo;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Navegación "atrás/adelante" entre reportes, con dos pilas (como un navegador web):
 * - atras: reportes ya vistos antes del actual.
 * - adelante: reportes a los que se puede volver tras retroceder.
 * ArrayDeque se usa como pila: push() apila y pop() desapila el último (LIFO).
 */
public class NavegadorReportes {

    private final Deque<String> atras = new ArrayDeque<>();
    private final Deque<String> adelante = new ArrayDeque<>();
    private String actual = null;

    /** Registra un reporte nuevo como el actual. Borra el historial de "adelante". */
    public void visitar(String reporte) {
        if (actual != null) {
            atras.push(actual);
        }
        actual = reporte;
        adelante.clear();
    }

    public String retroceder() {
        if (atras.isEmpty()) {
            throw new IllegalStateException("No hay reportes anteriores.");
        }
        adelante.push(actual);
        actual = atras.pop();
        return actual;
    }

    public String avanzar() {
        if (adelante.isEmpty()) {
            throw new IllegalStateException("No hay reportes siguientes.");
        }
        atras.push(actual);
        actual = adelante.pop();
        return actual;
    }

    public String getActual() { return actual; }
    public boolean hayAtras() { return !atras.isEmpty(); }
    public boolean hayAdelante() { return !adelante.isEmpty(); }
}
