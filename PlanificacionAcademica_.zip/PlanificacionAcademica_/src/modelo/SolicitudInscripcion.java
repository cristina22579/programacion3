package modelo;

/** Una línea válida del CSV: un estudiante que quiere inscribirse en una materia. */
public class SolicitudInscripcion {

    private final int linea;              // número de línea en el archivo (para mensajes)
    private final String idEstudiante;
    private final String codigoMateria;

    public SolicitudInscripcion(int linea, String idEstudiante, String codigoMateria) {
        this.linea = linea;
        this.idEstudiante = idEstudiante;
        this.codigoMateria = codigoMateria;
    }

    public int getLinea() { return linea; }
    public String getIdEstudiante() { return idEstudiante; }
    public String getCodigoMateria() { return codigoMateria; }
}
