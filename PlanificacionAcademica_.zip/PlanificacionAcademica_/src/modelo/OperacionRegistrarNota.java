package modelo;

import estructuras.Operacion;

/** Registro (o corrección) de una nota. Guarda la nota anterior para poder restaurarla. */
public class OperacionRegistrarNota implements Operacion {

    private final Estudiante estudiante;
    private final int semestre;
    private final String codigoMateria;
    private final Double notaAnterior;   // null = la materia no tenía nota
    private final double notaNueva;

    public OperacionRegistrarNota(Estudiante estudiante, int semestre, String codigoMateria,
                                  Double notaAnterior, double notaNueva) {
        this.estudiante = estudiante;
        this.semestre = semestre;
        this.codigoMateria = codigoMateria;
        this.notaAnterior = notaAnterior;
        this.notaNueva = notaNueva;
    }

    @Override
    public String deshacer() {
        if (notaAnterior == null) {
            estudiante.eliminarNota(semestre, codigoMateria);
            return "Operacion deshecha: se quito la nota de " + codigoMateria + " de " + estudiante.getNombre();
        }
        estudiante.registrarNota(semestre, codigoMateria, notaAnterior);
        return "Operacion deshecha: la nota de " + codigoMateria + " vuelve a " + notaAnterior;
    }

    @Override
    public String rehacer() {
        estudiante.registrarNota(semestre, codigoMateria, notaNueva);
        return "Operacion rehecha: " + codigoMateria + " = " + notaNueva + " para " + estudiante.getNombre();
    }
}
