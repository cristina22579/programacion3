package modelo;

/**
 * Mapa del campus como grafo NO dirigido representado con una matriz de adyacencia.
 * distancias[i][j] = metros entre el edificio i y el j; 0 significa "sin conexión directa".
 * Al ser no dirigido, la matriz es simétrica: distancias[i][j] == distancias[j][i].
 */
public class Campus {

    public static final int MAX_EDIFICIOS = 10;

    private final String[] nombres = new String[MAX_EDIFICIOS];
    private final int[][] distancias = new int[MAX_EDIFICIOS][MAX_EDIFICIOS];
    private int cantidad = 0;

    public int getCantidad() { return cantidad; }

    public String getNombre(int indice) { return nombres[indice]; }

    /** Agrega un edificio y devuelve su índice. */
    public int agregarEdificio(String nombre) {
        if (cantidad >= MAX_EDIFICIOS) {
            throw new IllegalStateException("No caben mas edificios (maximo " + MAX_EDIFICIOS + ").");
        }
        nombres[cantidad] = nombre;
        return cantidad++;
    }

    /** Busca el índice de un edificio por nombre, sin distinguir mayúsculas. */
    public int buscarIndice(String nombre) {
        for (int i = 0; i < cantidad; i++) {
            if (nombres[i].equalsIgnoreCase(nombre)) {
                return i;
            }
        }
        throw new IllegalArgumentException("No existe el edificio: " + nombre);
    }

    /** Conecta dos edificios con una distancia en metros (en ambos sentidos). */
    public void conectar(int a, int b, int metros) {
        if (a == b) {
            throw new IllegalArgumentException("Un edificio no se conecta consigo mismo.");
        }
        if (metros <= 0) {
            throw new IllegalArgumentException("La distancia debe ser mayor que 0.");
        }
        distancias[a][b] = metros;
        distancias[b][a] = metros;
    }

    public int distanciaDirecta(int a, int b) {
        return distancias[a][b];
    }

    /**
     * Algoritmo de Dijkstra sobre la matriz de adyacencia (versión O(N^2), sin cola de prioridad).
     * Idea: repetir "tomar el edificio no visitado con menor distancia conocida y
     * ver si pasando por él se mejora la distancia a sus vecinos".
     */
    public Ruta calcularRutaMasCorta(int origen, int destino) {
        int n = cantidad;
        int[] dist = new int[n];            // mejor distancia conocida desde el origen
        int[] previo = new int[n];          // de qué edificio vengo en el mejor camino
        boolean[] visitado = new boolean[n];
        for (int i = 0; i < n; i++) {
            dist[i] = Integer.MAX_VALUE;
            previo[i] = -1;
        }
        dist[origen] = 0;

        for (int iteracion = 0; iteracion < n; iteracion++) {
            // 1) elegir el no visitado con menor distancia
            int u = -1;
            for (int i = 0; i < n; i++) {
                if (!visitado[i] && dist[i] != Integer.MAX_VALUE && (u == -1 || dist[i] < dist[u])) {
                    u = i;
                }
            }
            if (u == -1) break;             // lo que queda no es alcanzable
            visitado[u] = true;

            // 2) relajar las conexiones de u
            for (int v = 0; v < n; v++) {
                if (distancias[u][v] > 0 && !visitado[v]) {
                    int nueva = dist[u] + distancias[u][v];
                    if (nueva < dist[v]) {
                        dist[v] = nueva;
                        previo[v] = u;
                    }
                }
            }
        }

        if (dist[destino] == Integer.MAX_VALUE) {
            throw new IllegalArgumentException("No existe ruta entre "
                    + nombres[origen] + " y " + nombres[destino] + ".");
        }

        // Reconstruir el camino yendo hacia atrás desde el destino
        int largo = 0;
        for (int actual = destino; actual != -1; actual = previo[actual]) {
            largo++;
        }
        int[] camino = new int[largo];
        int pos = largo - 1;
        for (int actual = destino; actual != -1; actual = previo[actual]) {
            camino[pos--] = actual;
        }
        return new Ruta(camino, dist[destino]);
    }
}
