package modelo;

/**
 * Clase abstracta base de la jerarquía de herencia.
 * Encapsula los datos comunes de cualquier persona del sistema.
 */
public abstract class Persona {

    private String nombre;
    private String id;
    private String email;

    public Persona(String nombre, String id, String email) {
        this.nombre = nombre;
        this.id = id;
        this.email = email;
    }

    public String getNombre() { return nombre; }
    public String getId() { return id; }
    public String getEmail() { return email; }

    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setEmail(String email) { this.email = email; }

    /**
     * Cada subclase decide cómo mostrar su información (polimorfismo).
     */
    public abstract void mostrarInformacion();
}
