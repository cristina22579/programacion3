package modelo;

import estructuras.Operacion;
import excepciones.HorarioConflictivoException;

/** Cambio en el horario de un aula: una reserva o una liberación. */
public class OperacionHorario implements Operacion {

    private final Aula aula;
    private final int dia;
    private final int hora;
    private final int duracion;
    private final boolean fueReserva;   // true = se reservó, false = se liberó

    public OperacionHorario(Aula aula, int dia, int hora, int duracion, boolean fueReserva) {
        this.aula = aula;
        this.dia = dia;
        this.hora = hora;
        this.duracion = duracion;
        this.fueReserva = fueReserva;
    }

    private String detalle() {
        return "aula " + aula.getNombre() + ", " + Aula.nombreDia(dia) + " " + hora + ":00 (" + duracion + "h)";
    }

    @Override
    public String deshacer() {
        if (fueReserva) {
            aula.liberar(dia, hora, duracion);
            return "Operacion deshecha: reserva eliminada en " + detalle();
        }
        aplicarReserva();
        return "Operacion deshecha: horario vuelto a reservar en " + detalle();
    }

    @Override
    public String rehacer() {
        if (fueReserva) {
            aplicarReserva();
            return "Operacion rehecha: reservado de nuevo " + detalle();
        }
        aula.liberar(dia, hora, duracion);
        return "Operacion rehecha: liberado de nuevo " + detalle();
    }

    private void aplicarReserva() {
        try {
            aula.reservar(dia, hora, duracion);
        } catch (HorarioConflictivoException ex) {
            throw new IllegalStateException("No se pudo reservar: " + ex.getMessage());
        }
    }
}
