package modelo;

import java.util.Locale;

/**
 * Construye el reporte académico de un estudiante recorriendo la matriz de notas.
 */
public class GeneradorReportes {

    private GeneradorReportes() { }   // clase de utilidad: no se instancia

    public static String generar(Estudiante e) {
        StringBuilder sb = new StringBuilder();
        StringBuilder reprobadas = new StringBuilder();
        int aprobadas = 0;
        int reprobadasCount = 0;
        boolean hayNotas = false;

        sb.append("--- REPORTE ACADEMICO ---\n");
        sb.append("Estudiante: ").append(e.getNombre()).append(" (ID: ").append(e.getId()).append(")\n");

        for (int i = 0; i < Estudiante.MAX_SEMESTRES; i++) {
            boolean semestreConNotas = false;
            StringBuilder bloque = new StringBuilder();
            for (int j = 0; j < Estudiante.MAX_MATERIAS; j++) {
                Double nota = e.getNota(i, j);
                if (nota == null) continue;
                semestreConNotas = true;
                String codigo = e.getCodigoMateria(i, j);
                bloque.append("  ").append(codigo).append(": ").append(formato(nota, 1)).append("\n");
                if (nota >= Estudiante.NOTA_APROBATORIA) {
                    aprobadas++;
                } else {
                    reprobadasCount++;
                    reprobadas.append("  Semestre ").append(i + 1).append(" - ")
                              .append(codigo).append(": ").append(formato(nota, 1)).append("\n");
                }
            }
            if (semestreConNotas) {
                hayNotas = true;
                sb.append("Semestre ").append(i + 1).append(":\n").append(bloque);
                sb.append("  Promedio: ").append(formato(e.promedioSemestre(i + 1), 2)).append("\n");
            }
        }

        if (!hayNotas) {
            sb.append("(sin notas registradas)\n");
        }
        sb.append("=== RESUMEN ===\n");
        sb.append("Promedio acumulado: ").append(formato(e.promedioAcumulado(), 2)).append("\n");
        sb.append("Materias aprobadas: ").append(aprobadas).append("\n");
        sb.append("Materias reprobadas: ").append(reprobadasCount).append("\n");
        if (reprobadasCount > 0) {
            sb.append("Detalle de reprobadas (nota < 3.0):\n").append(reprobadas);
        }
        return sb.toString();
    }

    /** Locale.US para que el decimal sea punto y no coma. */
    private static String formato(double valor, int decimales) {
        return String.format(Locale.US, "%." + decimales + "f", valor);
    }
}
