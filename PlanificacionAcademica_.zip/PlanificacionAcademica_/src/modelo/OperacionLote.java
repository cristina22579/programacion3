package modelo;

import estructuras.Operacion;
import java.util.List;

/**
 * Agrupa las operaciones de un procesamiento por lotes para que UN solo
 * "deshacer" revierta todo el lote (en orden inverso) y UN "rehacer" lo repita.
 */
public class OperacionLote implements Operacion {

    private final List<Operacion> operaciones;

    public OperacionLote(List<Operacion> operaciones) {
        this.operaciones = operaciones;
    }

    @Override
    public String deshacer() {
        for (int i = operaciones.size() - 1; i >= 0; i--) {
            operaciones.get(i).deshacer();
        }
        return "Operacion deshecha: lote de " + operaciones.size() + " inscripciones revertido";
    }

    @Override
    public String rehacer() {
        for (Operacion op : operaciones) {
            op.rehacer();
        }
        return "Operacion rehecha: lote de " + operaciones.size() + " inscripciones aplicado de nuevo";
    }
}
