package modelo;

import java.util.ArrayList;
import java.util.List;

/** Resumen de un procesamiento por lotes: detalle por solicitud y contadores. */
public class ResultadoLote {

    private final List<String> lineasIgnoradas = new ArrayList<>();
    private final List<String> detalle = new ArrayList<>();
    private int total = 0;
    private int exitosas = 0;
    private int fallidas = 0;

    public List<String> getLineasIgnoradas() { return lineasIgnoradas; }
    public List<String> getDetalle() { return detalle; }
    public int getTotal() { return total; }
    public int getExitosas() { return exitosas; }
    public int getFallidas() { return fallidas; }

    void setTotal(int total) { this.total = total; }
    void contarExitosa() { exitosas++; }
    void contarFallida() { fallidas++; }
}
