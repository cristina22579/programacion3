package modelo;

import java.util.LinkedList;

/**
 * Estudiante: hereda de Persona y agrega semestre, notas e historial.
 * Las notas se guardan en un arreglo nativo Double[10][20]:
 * 10 semestres máximo y 20 materias máximo por semestre.
 * Un arreglo paralelo String[10][20] guarda el código de la materia de cada nota.
 */
public class Estudiante extends Persona {

    public static final int MAX_SEMESTRES = 10;
    public static final int MAX_MATERIAS = 20;
    public static final double NOTA_APROBATORIA = 3.0;

    private int semestre;
    private Facultad facultad;                      // opcional (puede ser null)
    private final Double[][] notas;                 // null = sin nota registrada
    private final String[][] codigosMaterias;       // código de la materia de cada nota
    private final LinkedList<String> historialMaterias;  // materias aprobadas (lista enlazada de Java)

    public Estudiante(String nombre, String id, String email, int semestre) {
        super(nombre, id, email);
        this.semestre = semestre;
        this.notas = new Double[MAX_SEMESTRES][MAX_MATERIAS];
        this.codigosMaterias = new String[MAX_SEMESTRES][MAX_MATERIAS];
        this.historialMaterias = new LinkedList<>();
    }

    public int getSemestre() { return semestre; }
    public void setSemestre(int semestre) { this.semestre = semestre; }
    public Facultad getFacultad() { return facultad; }
    public void setFacultad(Facultad facultad) { this.facultad = facultad; }
    public LinkedList<String> getHistorialMaterias() { return historialMaterias; }

    /** Agrega al historial el código de una materia aprobada (sin duplicados). */
    public void agregarMateriaAprobada(String codigoMateria) {
        if (!historialMaterias.contains(codigoMateria)) {
            historialMaterias.add(codigoMateria);
        }
    }

    /** Indica si el estudiante ya aprobó la materia con ese código. */
    public boolean haAprobado(String codigoMateria) {
        return historialMaterias.contains(codigoMateria);
    }

    /** Nota en la posición indicada (índices desde 0). Devuelve null si no hay nota. */
    public Double getNota(int indiceSemestre, int indiceMateria) {
        return notas[indiceSemestre][indiceMateria];
    }

    /** Código de la materia en la posición indicada (índices desde 0). null si no hay. */
    public String getCodigoMateria(int indiceSemestre, int indiceMateria) {
        return codigosMaterias[indiceSemestre][indiceMateria];
    }

    /**
     * Registra la nota de una materia en un semestre (1 a 10).
     * Si la materia ya tenía nota en ese semestre, la actualiza; si no, usa la
     * primera columna libre. Actualiza el historial de materias aprobadas.
     */
    public void registrarNota(int semestreNota, String codigoMateria, double nota) {
        validarSemestre(semestreNota);
        if (nota < 0.0 || nota > 5.0) {
            throw new IllegalArgumentException("La nota debe estar entre 0.0 y 5.0.");
        }
        int s = semestreNota - 1;
        int columna = -1;
        int primeraLibre = -1;
        for (int j = 0; j < MAX_MATERIAS; j++) {
            if (codigoMateria.equals(codigosMaterias[s][j])) {
                columna = j;
                break;
            }
            if (primeraLibre == -1 && codigosMaterias[s][j] == null) {
                primeraLibre = j;
            }
        }
        if (columna == -1) {
            if (primeraLibre == -1) {
                throw new IllegalStateException("El semestre " + semestreNota
                        + " ya tiene " + MAX_MATERIAS + " materias registradas.");
            }
            columna = primeraLibre;
            codigosMaterias[s][columna] = codigoMateria;
        }
        notas[s][columna] = nota;
        actualizarHistorial(codigoMateria);
    }

    /** Nota de una materia en un semestre (1 a 10), o null si no tiene. */
    public Double getNotaDeMateria(int semestreNota, String codigoMateria) {
        validarSemestre(semestreNota);
        for (int j = 0; j < MAX_MATERIAS; j++) {
            if (codigoMateria.equals(codigosMaterias[semestreNota - 1][j])) {
                return notas[semestreNota - 1][j];
            }
        }
        return null;
    }

    /** Quita la nota de una materia en un semestre y actualiza el historial. */
    public void eliminarNota(int semestreNota, String codigoMateria) {
        validarSemestre(semestreNota);
        int s = semestreNota - 1;
        for (int j = 0; j < MAX_MATERIAS; j++) {
            if (codigoMateria.equals(codigosMaterias[s][j])) {
                codigosMaterias[s][j] = null;
                notas[s][j] = null;
            }
        }
        actualizarHistorial(codigoMateria);
    }

    /** Una materia está aprobada si alguna de sus notas registradas es >= 3.0. */
    private void actualizarHistorial(String codigoMateria) {
        boolean aprobada = false;
        for (int i = 0; i < MAX_SEMESTRES; i++) {
            for (int j = 0; j < MAX_MATERIAS; j++) {
                if (codigoMateria.equals(codigosMaterias[i][j])
                        && notas[i][j] != null && notas[i][j] >= NOTA_APROBATORIA) {
                    aprobada = true;
                }
            }
        }
        if (aprobada) {
            agregarMateriaAprobada(codigoMateria);
        } else {
            historialMaterias.remove(codigoMateria);
        }
    }

    private void validarSemestre(int semestreNota) {
        if (semestreNota < 1 || semestreNota > MAX_SEMESTRES) {
            throw new IllegalArgumentException("El semestre debe estar entre 1 y " + MAX_SEMESTRES + ".");
        }
    }

    /** Promedio de un semestre (1 a 10). Devuelve 0.0 si no hay notas. */
    public double promedioSemestre(int semestreNota) {
        validarSemestre(semestreNota);
        double suma = 0;
        int cantidad = 0;
        for (int j = 0; j < MAX_MATERIAS; j++) {
            Double n = notas[semestreNota - 1][j];
            if (n != null) {
                suma += n;
                cantidad++;
            }
        }
        return cantidad == 0 ? 0.0 : suma / cantidad;
    }

    /** Promedio acumulado de todas las notas registradas. Devuelve 0.0 si no hay notas. */
    public double promedioAcumulado() {
        double suma = 0;
        int cantidad = 0;
        for (int i = 0; i < MAX_SEMESTRES; i++) {
            for (int j = 0; j < MAX_MATERIAS; j++) {
                if (notas[i][j] != null) {
                    suma += notas[i][j];
                    cantidad++;
                }
            }
        }
        return cantidad == 0 ? 0.0 : suma / cantidad;
    }

    /** Sobrescritura del método abstracto de Persona. */
    @Override
    public void mostrarInformacion() {
        System.out.println("ID: " + getId());
        System.out.println("Nombre: " + getNombre());
        System.out.println("Email: " + getEmail());
        System.out.println("Semestre: " + semestre);
        if (facultad != null) {
            System.out.println("Facultad: " + facultad.getNombre());
        }
        double prom = promedioAcumulado();
        System.out.println("Promedio acumulado: " + prom
                + (prom == 0.0 ? " (sin notas aun)" : ""));
    }
}
