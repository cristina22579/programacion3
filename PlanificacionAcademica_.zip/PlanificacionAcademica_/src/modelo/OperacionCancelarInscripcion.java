package modelo;

import estructuras.Operacion;
import excepciones.CupoLlenoException;

/**
 * Cancelación de una inscripción. Si había alguien en cola, ese estudiante tomó el cupo
 * ('promovido'); para deshacer hay que devolverlo al FRENTE de la cola.
 */
public class OperacionCancelarInscripcion implements Operacion {

    private final Materia materia;
    private final Estudiante estudiante;
    private final Estudiante promovido;   // null si nadie estaba esperando

    public OperacionCancelarInscripcion(Materia materia, Estudiante estudiante, Estudiante promovido) {
        this.materia = materia;
        this.estudiante = estudiante;
        this.promovido = promovido;
    }

    @Override
    public String deshacer() {
        try {
            if (promovido != null) {
                materia.cancelar(promovido);
                materia.encolarAlFrente(promovido);
            }
            materia.inscribir(estudiante);
            return "Operacion deshecha: " + estudiante.getNombre() + " vuelve a estar inscrito en " + materia.getCodigo();
        } catch (CupoLlenoException ex) {
            throw new IllegalStateException("No se pudo deshacer: " + ex.getMessage());
        }
    }

    @Override
    public String rehacer() {
        try {
            materia.cancelar(estudiante);
            if (promovido != null) {
                materia.retirarDeCola(promovido);
                materia.inscribir(promovido);
            }
            return "Operacion rehecha: " + estudiante.getNombre() + " cancelo su inscripcion en " + materia.getCodigo();
        } catch (CupoLlenoException ex) {
            throw new IllegalStateException("No se pudo rehacer: " + ex.getMessage());
        }
    }
}
