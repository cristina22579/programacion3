package modelo;

/**
 * Resultado de calcular una ruta: los índices de los edificios del camino
 * (en orden, de origen a destino) y la distancia total en metros.
 */
public class Ruta {

    private final int[] camino;
    private final int distanciaTotal;

    public Ruta(int[] camino, int distanciaTotal) {
        this.camino = camino;
        this.distanciaTotal = distanciaTotal;
    }

    public int[] getCamino() { return camino.clone(); }
    public int getDistanciaTotal() { return distanciaTotal; }
}
