package modelo;

import excepciones.EstudianteNoEncontradoException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Administra los estudiantes del sistema.
 * Usa un HashMap<String, Estudiante> como índice rápido por ID:
 * buscar, insertar y eliminar cuestan O(1) en promedio.
 */
public class GestorEstudiantes {

    private final Map<String, Estudiante> indice = new HashMap<>();

    /** Registra un estudiante. Lanza IllegalArgumentException si el ID ya existe. */
    public void registrar(Estudiante estudiante) {
        if (indice.containsKey(estudiante.getId())) {
            throw new IllegalArgumentException("Ya existe un estudiante con ID: " + estudiante.getId());
        }
        indice.put(estudiante.getId(), estudiante);
    }

    /** Busca por ID. Lanza EstudianteNoEncontradoException si no existe. */
    public Estudiante buscar(String id) throws EstudianteNoEncontradoException {
        Estudiante e = indice.get(id);
        if (e == null) {
            throw new EstudianteNoEncontradoException("No existe estudiante con ID: " + id);
        }
        return e;
    }

    /**
     * Elimina al estudiante y lo devuelve.
     * Se devuelve el objeto para poder guardarlo en la pila de deshacer
     * y restaurarlo después con registrar().
     */
    public Estudiante eliminar(String id) throws EstudianteNoEncontradoException {
        Estudiante e = buscar(id);
        indice.remove(id);
        return e;
    }

    /** Devuelve una copia de la lista de estudiantes (no expone el mapa interno). */
    public List<Estudiante> listar() {
        return new ArrayList<>(indice.values());
    }

    public int cantidad() {
        return indice.size();
    }
}
