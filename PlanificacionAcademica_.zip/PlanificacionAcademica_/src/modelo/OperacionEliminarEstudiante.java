package modelo;

import estructuras.Operacion;
import excepciones.EstudianteNoEncontradoException;

/** Baja de un estudiante. Guarda el objeto completo para poder restaurarlo. */
public class OperacionEliminarEstudiante implements Operacion {

    private final GestorEstudiantes gestor;
    private final Estudiante estudiante;

    public OperacionEliminarEstudiante(GestorEstudiantes gestor, Estudiante estudiante) {
        this.gestor = gestor;
        this.estudiante = estudiante;
    }

    @Override
    public String deshacer() {
        gestor.registrar(estudiante);
        return "Operacion deshecha: " + estudiante.getNombre() + " fue restaurado";
    }

    @Override
    public String rehacer() {
        try {
            gestor.eliminar(estudiante.getId());
            return "Operacion rehecha: " + estudiante.getNombre() + " fue eliminado de nuevo";
        } catch (EstudianteNoEncontradoException ex) {
            throw new IllegalStateException("No se pudo rehacer: " + ex.getMessage());
        }
    }
}
