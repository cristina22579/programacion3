package modelo;

import excepciones.ColaDeEsperaVaciaException;
import excepciones.CupoLlenoException;
import excepciones.PreRequisitoNoAprobadoException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Administra las materias: creación, prerrequisitos, inscripciones y cola de espera.
 */
public class GestorMaterias {

    private final Map<String, Materia> materias = new HashMap<>();

    public void crear(Materia materia) {
        if (materias.containsKey(materia.getCodigo())) {
            throw new IllegalArgumentException("Ya existe la materia: " + materia.getCodigo());
        }
        materias.put(materia.getCodigo(), materia);
    }

    public Materia buscar(String codigo) {
        Materia m = materias.get(codigo);
        if (m == null) {
            throw new IllegalArgumentException("No existe la materia: " + codigo);
        }
        return m;
    }

    public void agregarPrerrequisito(String codigoMateria, String codigoPrerrequisito) {
        Materia materia = buscar(codigoMateria);
        buscar(codigoPrerrequisito);   // valida que el prerrequisito exista
        if (codigoMateria.equals(codigoPrerrequisito)) {
            throw new IllegalArgumentException("Una materia no puede ser prerrequisito de si misma.");
        }
        if (materia.getPrerrequisitos().contains(codigoPrerrequisito)) {
            throw new IllegalArgumentException("Ese prerrequisito ya fue agregado.");
        }
        materia.agregarPrerrequisito(codigoPrerrequisito);
    }

    /**
     * Inscribe al estudiante si cumple todos los prerrequisitos.
     * @return true si quedó inscrito; false si la materia estaba llena y pasó a la cola de espera.
     */
    public boolean inscribir(Estudiante estudiante, String codigoMateria)
            throws PreRequisitoNoAprobadoException {
        Materia materia = buscar(codigoMateria);

        if (materia.estaInscrito(estudiante) || materia.estaEnCola(estudiante)) {
            throw new IllegalArgumentException("El estudiante ya esta inscrito o en cola en " + codigoMateria);
        }
        verificarPrerrequisitos(estudiante, materia);

        try {
            materia.inscribir(estudiante);
            return true;
        } catch (CupoLlenoException ex) {
            materia.encolar(estudiante);
            return false;
        }
    }

    /** Lanza PreRequisitoNoAprobadoException indicando todos los prerrequisitos que faltan. */
    private void verificarPrerrequisitos(Estudiante estudiante, Materia materia)
            throws PreRequisitoNoAprobadoException {
        StringBuilder faltantes = new StringBuilder();
        for (String codigoPre : materia.getPrerrequisitos()) {
            if (!estudiante.haAprobado(codigoPre)) {
                if (faltantes.length() > 0) faltantes.append(", ");
                faltantes.append(codigoPre);
            }
        }
        if (faltantes.length() > 0) {
            throw new PreRequisitoNoAprobadoException(
                    "Faltan prerrequisitos para " + materia.getCodigo() + ": " + faltantes);
        }
    }

    /**
     * Cancela la inscripción y asigna el cupo al primero de la cola, si hay alguien.
     * @return el estudiante que tomó el cupo, o null si no había nadie en cola.
     */
    public Estudiante cancelarInscripcion(Estudiante estudiante, String codigoMateria) {
        Materia materia = buscar(codigoMateria);
        if (!materia.cancelar(estudiante)) {
            throw new IllegalArgumentException("El estudiante no esta inscrito en " + codigoMateria);
        }
        try {
            Estudiante promovido = materia.siguienteDeCola();
            materia.inscribir(promovido);   // hay cupo porque acabamos de liberar uno
            return promovido;
        } catch (ColaDeEsperaVaciaException ex) {
            return null;                    // nadie esperando: el cupo queda libre
        } catch (CupoLlenoException ex) {
            throw new IllegalStateException("Error interno: no habia cupo tras cancelar.", ex);
        }
    }

    public List<Estudiante> verCola(String codigoMateria) {
        return buscar(codigoMateria).verCola();
    }
}
