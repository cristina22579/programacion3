package modelo;

import excepciones.ColaDeEsperaVaciaException;
import excepciones.CupoLlenoException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Deque;

/**
 * Materia con cupos limitados.
 * - prerrequisitos: lista enlazada (LinkedList) con los códigos de materias previas.
 * - colaEspera: cola FIFO (ArrayDeque) de estudiantes cuando no hay cupo.
 */
public class Materia {

    private final String codigo;
    private final String nombre;
    private final int cuposMaximos;
    private final int creditos;
    private final LinkedList<String> prerrequisitos = new LinkedList<>();
    private final List<Estudiante> inscritos = new ArrayList<>();
    private final Deque<Estudiante> colaEspera = new ArrayDeque<>();

    public Materia(String codigo, String nombre, int cuposMaximos, int creditos) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.cuposMaximos = cuposMaximos;
        this.creditos = creditos;
    }

    public String getCodigo() { return codigo; }
    public String getNombre() { return nombre; }
    public int getCuposMaximos() { return cuposMaximos; }
    public int getCreditos() { return creditos; }
    public LinkedList<String> getPrerrequisitos() { return prerrequisitos; }

    public int cuposDisponibles() { return cuposMaximos - inscritos.size(); }
    public boolean estaLlena() { return cuposDisponibles() <= 0; }
    public boolean estaInscrito(Estudiante e) { return inscritos.contains(e); }
    public boolean estaEnCola(Estudiante e) { return colaEspera.contains(e); }

    public void agregarPrerrequisito(String codigoPrerrequisito) {
        prerrequisitos.add(codigoPrerrequisito);
    }

    /** Inscribe al estudiante. Lanza CupoLlenoException si no hay cupos. */
    public void inscribir(Estudiante e) throws CupoLlenoException {
        if (estaLlena()) {
            throw new CupoLlenoException("La materia " + codigo + " no tiene cupos disponibles.");
        }
        inscritos.add(e);
    }

    /** Quita al estudiante de los inscritos. Devuelve true si estaba inscrito. */
    public boolean cancelar(Estudiante e) {
        return inscritos.remove(e);
    }

    /** Agrega al final de la cola de espera. */
    public void encolar(Estudiante e) {
        colaEspera.offer(e);
    }

    /** Pone al estudiante al FRENTE de la cola (usado al deshacer una cancelación). */
    public void encolarAlFrente(Estudiante e) {
        colaEspera.addFirst(e);
    }

    /** Quita a un estudiante de la cola de espera. Devuelve true si estaba. */
    public boolean retirarDeCola(Estudiante e) {
        return colaEspera.remove(e);
    }

    /** Saca al primero de la cola. Lanza ColaDeEsperaVaciaException si no hay nadie. */
    public Estudiante siguienteDeCola() throws ColaDeEsperaVaciaException {
        Estudiante siguiente = colaEspera.poll();   // poll() devuelve null si la cola está vacía
        if (siguiente == null) {
            throw new ColaDeEsperaVaciaException("La cola de espera de " + codigo + " esta vacia.");
        }
        return siguiente;
    }

    /** Copia de la cola, en orden, para mostrarla sin modificarla. */
    public List<Estudiante> verCola() {
        return new ArrayList<>(colaEspera);
    }
}
