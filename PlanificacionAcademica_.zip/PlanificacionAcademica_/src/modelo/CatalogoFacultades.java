package modelo;

/**
 * Lista FIJA de facultades en un arreglo nativo Facultad[5].
 * El tamaño no cambia: si ya están las 5, no se puede agregar otra.
 */
public class CatalogoFacultades {

    public static final int CAPACIDAD = 5;

    private final Facultad[] facultades = new Facultad[CAPACIDAD];
    private int cantidad = 0;

    public void agregar(Facultad facultad) {
        if (cantidad >= CAPACIDAD) {
            throw new IllegalStateException("El catalogo esta lleno (maximo " + CAPACIDAD + " facultades).");
        }
        facultades[cantidad++] = facultad;
    }

    public int getCantidad() { return cantidad; }

    /** Devuelve la facultad en la posición 1..cantidad (como se muestra al usuario). */
    public Facultad obtener(int posicion) {
        if (posicion < 1 || posicion > cantidad) {
            throw new IllegalArgumentException("Facultad invalida. Elija entre 1 y " + cantidad + ".");
        }
        return facultades[posicion - 1];
    }
}
