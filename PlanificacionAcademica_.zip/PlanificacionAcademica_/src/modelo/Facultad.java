package modelo;

/** Una facultad de la universidad. */
public class Facultad {

    private final String codigo;
    private final String nombre;

    public Facultad(String codigo, String nombre) {
        this.codigo = codigo;
        this.nombre = nombre;
    }

    public String getCodigo() { return codigo; }
    public String getNombre() { return nombre; }

    @Override
    public String toString() {
        return codigo + " - " + nombre;
    }
}
