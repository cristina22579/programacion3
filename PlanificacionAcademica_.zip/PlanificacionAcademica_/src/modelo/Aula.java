package modelo;

import excepciones.HorarioConflictivoException;

/**
 * Aula con su horario semanal en una matriz boolean[7][24]:
 * filas = días (0 = Domingo ... 6 = Sábado), columnas = horas (0 a 23).
 * true = hora ocupada, false = hora libre.
 */
public class Aula {

    public static final int DIAS = 7;
    public static final int HORAS = 24;
    private static final String[] NOMBRES_DIAS =
            {"Domingo", "Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado"};

    private final String nombre;
    private final int capacidad;
    private final boolean[][] horario = new boolean[DIAS][HORAS];   // todo false = todo libre

    public Aula(String nombre, int capacidad) {
        this.nombre = nombre;
        this.capacidad = capacidad;
    }

    public String getNombre() { return nombre; }
    public int getCapacidad() { return capacidad; }

    public static String nombreDia(int dia) { return NOMBRES_DIAS[dia]; }

    /** Valida día, hora y duración. Lanza IllegalArgumentException si algo está fuera de rango. */
    public void validarRango(int dia, int hora, int duracion) {
        if (dia < 0 || dia >= DIAS) {
            throw new IllegalArgumentException("El dia debe estar entre 0 (Domingo) y 6 (Sabado).");
        }
        if (hora < 0 || hora >= HORAS) {
            throw new IllegalArgumentException("La hora debe estar entre 0 y 23.");
        }
        if (duracion < 1 || hora + duracion > HORAS) {
            throw new IllegalArgumentException("La duracion debe ser al menos 1 y terminar antes de las 24:00.");
        }
    }

    /** Consulta si una hora está libre (true = libre). */
    public boolean consultarDisponibilidad(int dia, int hora) {
        validarRango(dia, hora, 1);
        return !horario[dia][hora];
    }

    /**
     * Reserva 'duracion' horas seguidas. Primero verifica TODAS las horas y solo
     * si todas están libres las marca; así nunca queda una reserva a medias.
     */
    public void reservar(int dia, int hora, int duracion) throws HorarioConflictivoException {
        validarRango(dia, hora, duracion);
        for (int h = hora; h < hora + duracion; h++) {
            if (horario[dia][h]) {
                throw new HorarioConflictivoException(
                        nombreDia(dia) + " " + h + ":00 ya esta reservado");
            }
        }
        for (int h = hora; h < hora + duracion; h++) {
            horario[dia][h] = true;
        }
    }

    /** Libera horas reservadas. Lanza IllegalArgumentException si alguna no estaba reservada. */
    public void liberar(int dia, int hora, int duracion) {
        validarRango(dia, hora, duracion);
        for (int h = hora; h < hora + duracion; h++) {
            if (!horario[dia][h]) {
                throw new IllegalArgumentException(
                        nombreDia(dia) + " " + h + ":00 no estaba reservado");
            }
        }
        for (int h = hora; h < hora + duracion; h++) {
            horario[dia][h] = false;
        }
    }
}
