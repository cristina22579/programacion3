package modelo;

import estructuras.HistorialOperaciones;
import estructuras.Operacion;
import excepciones.ArchivoInvalidoException;
import excepciones.EstudianteNoEncontradoException;
import excepciones.PreRequisitoNoAprobadoException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;

/**
 * Procesamiento por lotes de inscripciones desde un CSV.
 * 1) Lee el archivo y ENCOLA cada solicitud válida (Queue FIFO).
 * 2) Saca las solicitudes de la cola una por una, en orden, e intenta inscribir.
 * Cada línea del CSV tiene el formato: idEstudiante,codigoMateria
 */
public class ProcesadorLotes {

    private static final String ENCABEZADO = "idestudiante,codigomateria";

    private final GestorEstudiantes gestorEstudiantes;
    private final GestorMaterias gestorMaterias;
    private final HistorialOperaciones historial;

    public ProcesadorLotes(GestorEstudiantes gestorEstudiantes, GestorMaterias gestorMaterias,
                           HistorialOperaciones historial) {
        this.gestorEstudiantes = gestorEstudiantes;
        this.gestorMaterias = gestorMaterias;
        this.historial = historial;
    }

    public ResultadoLote procesar(String rutaArchivo) throws ArchivoInvalidoException {
        ResultadoLote resultado = new ResultadoLote();
        Queue<SolicitudInscripcion> cola = new ArrayDeque<>();
        leerArchivo(rutaArchivo, cola, resultado);
        resultado.setTotal(cola.size());

        List<Operacion> realizadas = new ArrayList<>();
        int total = cola.size();
        int numero = 0;
        while (!cola.isEmpty()) {
            SolicitudInscripcion s = cola.poll();     // siempre sale la más antigua
            numero++;
            String prefijo = "[" + numero + "/" + total + "] " + s.getIdEstudiante()
                    + " -> " + s.getCodigoMateria() + " -> ";
            try {
                Estudiante e = gestorEstudiantes.buscar(s.getIdEstudiante());
                Materia m = gestorMaterias.buscar(s.getCodigoMateria());
                boolean inscrito = gestorMaterias.inscribir(e, s.getCodigoMateria());
                realizadas.add(new OperacionInscribir(m, e, inscrito));
                if (inscrito) {
                    resultado.contarExitosa();
                    resultado.getDetalle().add(prefijo + "Exitosa");
                } else {
                    resultado.contarFallida();
                    resultado.getDetalle().add(prefijo
                            + "Fallida (materia llena, agregado a cola de espera)");
                }
            } catch (EstudianteNoEncontradoException ex) {
                registrarFallo(resultado, prefijo, ex.getMessage());
            } catch (PreRequisitoNoAprobadoException ex) {
                registrarFallo(resultado, prefijo, ex.getMessage());
            } catch (IllegalArgumentException ex) {   // materia inexistente o ya inscrito
                registrarFallo(resultado, prefijo, ex.getMessage());
            }
        }

        if (!realizadas.isEmpty()) {
            historial.registrar(new OperacionLote(realizadas));   // todo el lote se deshace de una vez
        }
        return resultado;
    }

    private void registrarFallo(ResultadoLote resultado, String prefijo, String motivo) {
        resultado.contarFallida();
        resultado.getDetalle().add(prefijo + "Fallida (" + motivo + ")");
    }

    /** Lee el CSV y llena la cola. Lanza ArchivoInvalidoException si el archivo no sirve. */
    private void leerArchivo(String rutaArchivo, Queue<SolicitudInscripcion> cola, ResultadoLote resultado)
            throws ArchivoInvalidoException {
        if (rutaArchivo == null || rutaArchivo.trim().isEmpty()) {
            throw new ArchivoInvalidoException("Debe indicar la ruta del archivo.");
        }
        if (!rutaArchivo.toLowerCase().endsWith(".csv")) {
            throw new ArchivoInvalidoException("El archivo debe tener extension .csv");
        }
        Path ruta;
        try {
            ruta = Paths.get(rutaArchivo.trim());
        } catch (InvalidPathException ex) {
            throw new ArchivoInvalidoException("Ruta no valida: " + rutaArchivo);
        }
        if (!Files.isRegularFile(ruta)) {
            throw new ArchivoInvalidoException("No se encontro el archivo: " + rutaArchivo);
        }

        List<String> lineas;
        try {
            lineas = Files.readAllLines(ruta, StandardCharsets.UTF_8);
        } catch (IOException ex) {
            throw new ArchivoInvalidoException("No se pudo leer el archivo: " + ex.getMessage());
        }

        boolean encabezadoVisto = false;
        for (int i = 0; i < lineas.size(); i++) {
            String linea = lineas.get(i).replace("\uFEFF", "").trim();   // quita BOM y espacios
            int numeroLinea = i + 1;
            if (linea.isEmpty() || linea.startsWith("#")) {
                continue;
            }
            if (!encabezadoVisto && linea.replace(" ", "").equalsIgnoreCase(ENCABEZADO)) {
                encabezadoVisto = true;
                continue;
            }
            encabezadoVisto = true;   // el encabezado solo puede ser la primera línea con contenido

            String[] partes = linea.split(",", -1);
            if (partes.length != 2 || partes[0].trim().isEmpty() || partes[1].trim().isEmpty()) {
                resultado.getLineasIgnoradas().add("Linea " + numeroLinea
                        + " ignorada (formato invalido): " + linea);
                continue;
            }
            cola.offer(new SolicitudInscripcion(numeroLinea, partes[0].trim(), partes[1].trim()));
        }

        if (cola.isEmpty()) {
            throw new ArchivoInvalidoException("El archivo no contiene solicitudes validas.");
        }
    }
}
